#include <stdio.h>
#include <stdlib.h>

int i;
int main()
{
    for (i=1;i<=20;i++)
    printf("Esta e a mensagem %d\n",i);
    return 0;
}
